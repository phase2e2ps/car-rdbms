<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    require_once "../db/contact-class.php";


    #------------------------------------------------------------------------------------------#
        // global variables - preparation
        $action['page'] = 'Contact-form';
        $action['subpage'] = isset($_GET['subpage']) ? $_GET['subpage'] : 'contact';
    #------------------------------------------------------------------------------------------#



    #------------------------------------------------------------------------------------------#
        //=====>preparation for form submition<=====//

        // if the form submitted successfully the server use this first line "activeUser"
        if (isset($_GET['function']) && $_GET['function'] === 'sendMessage')
        {
            $handler = new activeUser($action);
            $handler->session_contact();
        }

        // else if the form failed to submit the server use this line "defaultUser"
        else {
            new defaultUser($action);
        }
    #------------------------------------------------------------------------------------------#



    #------------------------------------------------------------------------------------------#
        class defaultUser
        {
            private $page      = "";
            private $subpage   = "";
            private $user      = "";

            function __construct($page)
            {
                $this->page     = $page ['page'];
                $this->subpage  = $page ['subpage'];
                $this->user = new Contact();

                include "../views/contact.php";
                exit;
            }
        }
    #------------------------------------------------------------------------------------------#



    #------------------------------------------------------------------------------------------#
        class activeUser
        {
            private $page     = "";
            private $subpage  = "";
            private $user     = "";

            function __construct($page)
            {
                $this->page     = $page ['page'];
                $this->subpage  = $page ['subpage'];
                $this->user = new Contact();
            }

            // handle contact form submittion
            function session_contact()
            {
                if ($_SERVER['REQUEST_METHOD'] === 'POST')
                {
                    $data = 
                    [
                        'name_tb'     =>  $_POST['name'] ?? '',
                        'email_tb'    =>  $_POST['email'] ?? '',
                        'address_tb'  =>  $_POST['address'] ?? '',
                        'contact_no'  =>  $_POST['contact'] ?? '',
                        'message_tb'  =>  $_POST['message'] ?? ''
                    ];

                    // check if the form was submitted successfully
                    if ($this->user->sendMessage($data))
                    {
                        $_SESSION['session_contact'] = true;
                        echo "<script>
                                    alert ('Message Sent Successfully!'); 
                                    window.location.href='../views/nav-client-bookings.php'
                              </script>";
                    }

                    // else if failed to submit the form
                    echo  "<script>alert('Failed to save contact message.');</script>";
                }
            }
        }
    #------------------------------------------------------------------------------------------#
?>