<style>
    .video {
        margin-left: 5%;
        height: 600px;
        object-fit: cover;
    }
</style>

<video class="video"
    src="https://framerusercontent.com/assets/jPGmgjk0UnrlNS7OFk2YvyM4c.mp4" loop="" muted="" playsinline="" autoplay="" width="90%">
</video>

<!--<video class="video"
    source type="video/mp4" src="https://v.ftcdn.net/00/91/83/42/700_F_91834275_K57oqSVXcG8Gq4dwI5hhNL9gzdiRgPGq_ST.mp4" loop="" muted="" playsinline="" autoplay="" width="90%">
</video>








