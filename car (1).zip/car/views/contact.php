    <!--Navigation Bar-->
    <?php
    include "../nav/header.php";
    ?>
    <!--Navigation Bar-->

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

    <!-- Custom CSS -->
    <style>
        /* ---------- GLOBAL ---------- */
        body {
            font-family: 'Segoe UI', sans-serif;
            line-height: 1.6;
            scroll-behavior: smooth;
        }

        a {
            text-decoration: none;
        }

        /* ---------- NAVBAR ---------- */
        .navbar-dark .navbar-nav .nav-link {
            color: #fff;
            transition: color 0.3s;
        }

        .navbar-dark .navbar-nav .nav-link:hover {
            color: #ffc107;
        }

        .navbar-brand svg {
            fill: #fff;
        }

        /* ---------- HERO ---------- */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://framerusercontent.com/assets/jPGmgjk0UnrlNS7OFk2YvyM4c.mp4') center/cover no-repeat;
            color: #fff;
            text-align: center;
            padding: 120px 15px;
        }

        .hero h1 {
            font-size: 3rem;
            font-weight: 700;
        }

        .hero p {
            font-size: 1.2rem;
        }

        .btn-warning {
            font-weight: 600;
            border-radius: 50px;
            padding: 0.7rem 1.5rem;
        }

        /* ---------- WHY CHOOSE US ---------- */
        .features i {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }

        /* ---------- SERVICES ---------- */
        .services .card {
            border: none;
            border-radius: 16px;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .services .card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }

        /* ---------- STATS ---------- */
        .stats {
            color: #fff;
            text-align: center;
        }

        .stats h2 {
            font-size: 2rem;
            font-weight: 700;
        }

        .stats p {
            font-size: 1rem;
        }

        /* ---------- PRICING ---------- */
        .price {
            background: #f9f9f9;
            padding: 60px 0;
        }

        .price-item {
            border-radius: 16px;
            background: #fff;
            transition: all 0.3s;
            padding: 30px 20px;
        }

        .price-item:hover {
            transform: translateY(-8px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
        }

        .featured-item {
            border: 2px solid #6C63FF;
        }

        .featured-item h2 {
            color: #6C63FF;
        }

        .price-item ul li {
            padding: 0.6rem 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .btn-gradient {
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-gradient:hover {
            background: linear-gradient(135deg, #3b3f99, #6c70d8);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
        }

        /* ---------- TESTIMONIALS ---------- */
        blockquote {
            font-size: 1.1rem;
            font-style: italic;
        }

        /* ---------- CONTACT ---------- */
        iframe {
            border: none;
            border-radius: 16px;
        }

        /* ---------- FOOTER ---------- */
        .footer {
            background: #212529;
            color: #fff;
            padding: 30px 0;
        }

        .footer p {
            margin: 0;
        }
    </style>

    <!-- Contact Hero -->
    <section class="contact-hero d-flex align-items-center text-center text-white bg-info">
        <div class="overlay"></div>
        <div class="container position-relative">
            <h1 class="display-4 fw-bold">Contact Us</h1>
            <p class="lead">We’re here to help with all your car care needs</p>
        </div>
    </section>




    <!-- Contact CSS -->
    <style>
        .contact-hero {
            position: relative;
            height: 40vh;
            background: url('https://media.istockphoto.com/id/1177699635/photo/car-wash-detailing-station.jpg?s=612x612&w=0&k=20&c=HZXl1e_UcNwP0hXvi-5j7X3PZ-6PveDxR7oJ8CJc3bg=') center/cover no-repeat;
        }

        .contact-hero .overlay {
            position: absolute;
            inset: 0;
            background: rgba(0, 0, 0, 0.6);
        }

        .contact-hero .container {
            position: relative;
            z-index: 2;
        }

        .contact-section .card {
            border-radius: 12px;
        }
    </style>

    <!-- Contact Section -->
    <section class="contact-section py-5 bg-light">
        <div class="container">
            <div class="row g-5">
                <!-- Contact Info -->
                <div class="col-lg-5">
                    <h3 class="fw-bold mb-4">Get In Touch</h3>
                    <p class="mb-4">Have questions about our services or want to book a wash? Reach out to us!</p>
                    <ul class="list-unstyled">
                        <li class="mb-3"><i class="bi bi-geo-alt-fill text-primary me-2"></i> 123 Carwash Street, Manila, PH</li>
                        <li class="mb-3"><i class="bi bi-telephone-fill text-primary me-2"></i> +63 912 345 6789</li>
                        <li class="mb-3"><i class="bi bi-envelope-fill text-primary me-2"></i> carwash-rdbms@gmail.com</li>
                    </ul>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3859.936413078736!2d121.043700!3d14.583300!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2z!5e0!3m2!1sen!2sph!4v1615973071945"
                        width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>

                <!-- Contact Form -->
                <div class="col-lg-7">
                    <div class="card shadow border-0 p-4">
                        <h3 class="fw-bold mb-3">Send Us a Message</h3>
                        <form action="../controller/contact-handler.php?function=sendMessage" method="post" class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Name</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Phone</label>
                                <input type="text" name="contact" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Address</label>
                                <input type="text" name="address" class="form-control">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Message</label>
                                <textarea name="message" class="form-control" rows="5" required></textarea>
                            </div>
                            <div class="col-12 text-end">
                                <button type="submit" name="send" class="btn btn-primary px-4">Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include "../nav/footer.php"; ?>
    <!-- End Footer -->