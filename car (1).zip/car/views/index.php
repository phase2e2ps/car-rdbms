<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">
    <title>Carwash Management System</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

    <!-- Custom CSS -->
    <style>
        /* ---------- GLOBAL ---------- */
        body {
            font-family: 'Segoe UI', sans-serif;
            line-height: 1.6;
            scroll-behavior: smooth;
        }

        a {
            text-decoration: none;
        }

        /* ---------- NAVBAR ---------- */
        .navbar-dark .navbar-nav .nav-link {
            color: #fff;
            transition: color 0.3s;
        }

        .navbar-dark .navbar-nav .nav-link:hover {
            color: #ffc107;
        }

        .navbar-brand svg {
            fill: #fff;
        }

        /* ---------- HERO ---------- */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://framerusercontent.com/assets/jPGmgjk0UnrlNS7OFk2YvyM4c.mp4') center/cover no-repeat;
            color: #fff;
            text-align: center;
            padding: 200px 15px;
        }

        .hero h1 {
            font-size: 3rem;
            font-weight: 700;
        }

        .hero p {
            font-size: 1.2rem;
        }

        .btn-warning {
            font-weight: 600;
            border-radius: 50px;
            padding: 0.7rem 1.5rem;
        }

        /* ---------- WHY CHOOSE US ---------- */
        .features i {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }

        /* ---------- SERVICES ---------- */
        .services .card {
            border: none;
            border-radius: 16px;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .services .card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }

        /* ---------- STATS ---------- */
        .stats {
            color: #fff;
            text-align: center;
        }

        .stats h2 {
            font-size: 2rem;
            font-weight: 700;
        }

        .stats p {
            font-size: 1rem;
        }

        /* ---------- PRICING ---------- */
        .price {
            background: #f9f9f9;
            padding: 60px 0;
        }

        .price-item {
            border-radius: 16px;
            background: #fff;
            transition: all 0.3s;
            padding: 30px 20px;
        }

        .price-item:hover {
            transform: translateY(-8px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
        }

        .featured-item {
            border: 2px solid #6C63FF;
        }

        .featured-item h2 {
            color: #6C63FF;
        }

        .price-item ul li {
            padding: 0.6rem 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .btn-gradient {
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-gradient:hover {
            background: linear-gradient(135deg, #3b3f99, #6c70d8);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
        }

        /* ---------- TESTIMONIALS ---------- */
        blockquote {
            font-size: 1.1rem;
            font-style: italic;
        }

        /* ---------- CONTACT ---------- */
        iframe {
            border: none;
            border-radius: 16px;
            height: 50vh;

        }

        /* ---------- FOOTER ---------- */
        .footer {
            background: #212529;
            color: #fff;
            padding: 30px 0;
        }

        .footer p {
            margin: 0;
        }
    </style>
</head>

<body>

    <!--Navigation Bar-->
    <?php
    include "../nav/header.php";
    ?>



    <!-- Hero Section -->
    <section class="hero d-flex align-items-center text-center text-white" id="hero">
        <div class="overlay"></div>
        <div class="container position-relative">
            <h1 class="display-3 fw-bold">Carwash Management System</h1>
            <p class="lead mb-4">Fast, reliable, and affordable car care at your fingertips.</p>
            <a href="#plans" class="btn btn-warning btn-lg shadow-lg">Book a Wash Now</a>
        </div>
    </section>

    <!-- CSS -->
    <style>
        .hero {
            position: relative;
            min-height: 50vh;
            background-image: url('https://media.licdn.com/dms/image/v2/D5612AQFocjeksXrsOg/article-cover_image-shrink_720_1280/article-cover_image-shrink_720_1280/0/1703049956173?e=2147483647&v=beta&t=k7vqPdOw1hJ5LjxkbJabUwouKMqjKm4vHj3K2mafPsM');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            margin-top: 0.0%;
        }

        .hero .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.55);
            /* dark overlay for better text visibility */
        }

        .hero .container {
            position: relative;
            z-index: 2;
        }

        .hero h1 {
            font-size: 3.5rem;
            text-shadow: 0px 4px 15px rgba(0, 0, 0, 0.7);
        }

        .hero p {
            font-size: 1.25rem;
            margin-bottom: 1.5rem;
        }

        .hero .btn-warning {
            font-size: 1.2rem;
            font-weight: 600;
            padding: 0.75rem 2rem;
            border-radius: 50px;
            transition: all 0.3s ease-in-out;
        }

        .hero .btn-warning:hover {
            background: #e0a800;
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
        }
    </style>




    <!-- Why Choose Us -->
    <section class="features py-5 text-center">
        <div class="container">
            <h2 class="fw-bold mb-5">Why Choose Us?</h2>
            <div class="row g-4">
                <div class="col-md-4">
                    <i class="bi bi-clock-history text-primary"></i>
                    <h5 class="mt-3">Quick Service</h5>
                    <p>We value your time. Get your car sparkling clean in minutes.</p>
                </div>
                <div class="col-md-4">
                    <i class="bi bi-shield-check text-success"></i>
                    <h5 class="mt-3">Trusted & Safe</h5>
                    <p>Our experts ensure your car is handled with care.</p>
                </div>
                <div class="col-md-4">
                    <i class="bi bi-cash-coin text-warning"></i>
                    <h5 class="mt-3">Affordable Prices</h5>
                    <p>Premium cleaning packages without breaking the bank.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Booking Modal -->
    <?php
    include "../views/booking-modal.php";
    ?>
    <!-- End Booking Modal -->


    <!-- Services -->
    <section id="services" class="services py-5 bg-light">
        <div class="container text-center">
            <h2 class="fw-bold mb-5">Our Services</h2>
            <div class="row g-4">
                <div class="col-md-3">
                    <div class="card h-100 shadow-sm">
                        <i class="bi bi-water fs-1 text-primary mt-3"></i>
                        <div class="card-body">
                            <h5>Exterior Wash</h5>
                            <p>Shiny finish to make your car stand out.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card h-100 shadow-sm">
                        <i class="bi bi-wind fs-1 text-info mt-3"></i>
                        <div class="card-body">
                            <h5>Interior Cleaning</h5>
                            <p>Fresh, spotless, and comfortable interiors.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card h-100 shadow-sm">
                        <i class="bi bi-tools fs-1 text-danger mt-3"></i>
                        <div class="card-body">
                            <h5>Engine Wash</h5>
                            <p>Deep cleaning for long-lasting performance.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card h-100 shadow-sm">
                        <i class="bi bi-stars fs-1 text-warning mt-3"></i>
                        <div class="card-body">
                            <h5>Wax & Polish</h5>
                            <p>Protective shine for your car’s surface.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="py-5">
        <div class="container text-center">
            <h2 class="fw-bold mb-4">What Our Clients Say</h2>
            <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <blockquote class="blockquote">
                            <p>"Best carwash in town! My car looks brand new every time."</p>
                            <footer class="blockquote-footer">Maria Santos</footer>
                        </blockquote>
                    </div>
                    <div class="carousel-item">
                        <blockquote class="blockquote">
                            <p>"Quick and affordable service. Highly recommend!"</p>
                            <footer class="blockquote-footer">Juan Dela Cruz</footer>
                        </blockquote>
                    </div>
                    <div class="carousel-item">
                        <blockquote class="blockquote">
                            <p>"Professional staff and quality service. 5 stars!"</p>
                            <footer class="blockquote-footer">Anna Lopez</footer>
                        </blockquote>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats -->
    <section class="stats py-5" style="background: linear-gradient(135deg, #4e54c8, #8f94fb);">
        <div class="container">
            <div class="row g-4 text-center text-white">
                <div class="col-md-3">
                    <h2 class="fw-bold">5000+</h2>
                    <p>Cars Washed</p>
                </div>
                <div class="col-md-3">
                    <h2 class="fw-bold">3000+</h2>
                    <p>Happy Clients</p>
                </div>
                <div class="col-md-3">
                    <h2 class="fw-bold">50+</h2>
                    <p>Staff Members</p>
                </div>
                <div class="col-md-3">
                    <h2 class="fw-bold">10+</h2>
                    <p>Branches</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-5 bg-light">
        <div class="container text-center">
            <h2 class="fw-bold mb-4">Get in Touch</h2>
            <p>📍 Pawing, Leyte, Philippines</p>
            <p>📞 0912-345-6789 | ✉️ carwash-rdbms.com</p>
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3889.438061336476!2d124.965228875329!3d11.032345991789592!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33051c3e8c8f2b0f%3A0x1b82ec6d7d2c9a21!2sPawing%20Leyte%2C%20Philippines!5e0!3m2!1sen!2sus!4v1695600000000!5m2!1sen!2sus"
                width="100%" height="300"></iframe>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container text-center">
            <p>&copy; 2025 Carwash Management System. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Floating Book Now Button -->
    <style>
        #floatingBookBtn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 999;
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            color: #fff;
            border: none;
            border-radius: 50px;
            padding: 15px 25px;
            font-size: 1rem;
            font-weight: 600;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        #floatingBookBtn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.4);
        }
    </style>

    <button id="floatingBookBtn" data-bs-toggle="modal" data-bs-target="#myModal">
        🚗 Book Now
    </button>

</body>

</html>