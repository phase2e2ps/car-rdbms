<?php
    header("location: ./views/index.php");
?>