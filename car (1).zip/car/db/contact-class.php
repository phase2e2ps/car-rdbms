<?php
    require_once "db_connection.php";

    class Contact extends Database {
        private $conn;

        public function __construct()
        {
            $this->conn = $this->connect();
        }

        public function sendMessage($data)
        {
            $insert = "INSERT INTO contact_tb (name_tb, email_tb, address_tb, contact_no, message_tb)
                       VALUES (:name, :email, :address, :contact, :message)";
            $stmt = $this->conn->prepare($insert);
            $stmt->bindParam(":name", $data['name_tb']);
            $stmt->bindParam(":email", $data['email_tb']);
            $stmt->bindParam(":address", $data['address_tb']);
            $stmt->bindParam(":contact", $data['contact_no']);
            $stmt->bindParam(":message", $data['message_tb']);
            return $stmt->execute();
        }
    }
?>