<?php
include "db_connection.php";

class Booking extends Database
{
    private $conn;

    public function __construct()
    {
        $this->conn = $this->connect();
    }

    public function addBooking($data)
    {
        // Make sure extra_services is a string
        if (is_array($data['extra_services'])) {
            $data['extra_services'] = implode(',', $data['extra_services']);
        }
        
        $insert =
            "INSERT INTO booking_tb (booking_type, washing_point, name_tb, email_tb, phone_no, car_model, message_tb, extra_services, sched_tb, wash_time)
                       VALUES (:package_type, :washing_point, :full_name, :email, :mobile_no, :car_model, :message, :extra, :wash_date, :wash_time)";

        $stmt = $this->conn->prepare($insert);
        $stmt->bindParam(":package_type", $data['booking_type']);
        $stmt->bindParam(":washing_point", $data['washing_point']);
        $stmt->bindParam(":full_name", $data['name_tb']);
        $stmt->bindParam(":email", $data['email_tb']);
        $stmt->bindParam(":mobile_no", $data['phone_no']);
        $stmt->bindParam(":car_model", $data['car_model']);
        $stmt->bindParam(":message", $data['message_tb']);
        $stmt->bindParam(":extra", $data['extra_services']);
        $stmt->bindParam(":wash_date", $data['sched_tb']);
        $stmt->bindParam(":wash_time", $data['wash_time']);
        return $stmt->execute();
    }
}
