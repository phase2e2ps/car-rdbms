<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

<!-- Custom CSS -->
<style>
    /* ---------- GLOBAL ---------- */
    body {
        font-family: 'Segoe UI', sans-serif;
        line-height: 1.6;
        scroll-behavior: smooth;
        background-color: #f8f9fa;
        color: #212529;
    }

    a {
        text-decoration: none;
        transition: color 0.3s;
    }

    /* ---------- NAVBAR ---------- */
    .navbar-dark .navbar-nav .nav-link {
        color: #fff;
    }

    .navbar-dark .navbar-nav .nav-link:hover {
        color: #ffc107;
    }

    .navbar-brand svg {
        fill: #fff;
    }

    /* ---------- SIDEBAR ---------- */
    .sidebar {
        height: 100vh;
        background-color: #343a40;
        color: #fff;
        transition: all 0.3s;
    }

    .sidebar .nav-link {
        color: #adb5bd;
        transition: all 0.3s;
    }

    .sidebar .nav-link.active {
        background: rgba(255, 255, 255, 0.1);
        font-weight: bold;
        color: #fff;
    }

    .sidebar .nav-link:hover {
        background: rgba(255, 255, 255, 0.15);
        color: #fff;
    }

    /* ---------- CARDS ---------- */
    .card {
        border-radius: 12px;
        transition: all 0.3s;
    }

    .card:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    }

    /* ---------- FORMS ---------- */
    .form-control:focus {
        border-color: #6C63FF;
        box-shadow: 0 0 0 0.2rem rgba(108, 99, 255, 0.25);
    }

    .card button {
        transition: all 0.3s;
    }

    .card button:hover {
        transform: translateY(-2px);
    }

    /* ---------- BUTTONS ---------- */
    .btn-gradient {
        background: linear-gradient(135deg, #4e54c8, #8f94fb);
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-gradient:hover {
        background: linear-gradient(135deg, #3b3f99, #6c70d8);
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    /* ---------- SECTIONS ---------- */
    .section-title {
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 1rem;
        color: #6C63FF;
    }

    /* ---------- STATS CARDS ---------- */
    .stats-card {
        border-radius: 12px;
        padding: 20px;
        text-align: center;
        background: #fff;
        transition: all 0.3s;
    }

    .stats-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    }

    .stats-card h3 {
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
    }

    .stats-card p {
        color: #6c757d;
    }

    /* ---------- SOCIAL ICONS ---------- */
    .social-links a {
        font-size: 1.5rem;
        color: #6c757d;
        margin-right: 10px;
        transition: color 0.3s;
    }

    .social-links a:hover {
        color: #6C63FF;
    }
</style>

<div class="container-fluid">
    <div class="row">

        <!-- Sidebar -->
        <?php include "./sidebar.php"; ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="height: 55vh;">

            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h2">Settings</h1>
                <button class="btn btn-gradient">Preview Dashboard</button>
            </div>

            <!-- Business Info Card -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h3 class="section-title">Business Information</h3>
                    <form>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Business Name</label>
                                <input type="text" class="form-control" value="Pulse Carwash">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" value="info@carwash.com">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Contact</label>
                                <input type="text" class="form-control" value="+63 912 345 6789">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Website</label>
                                <input type="text" class="form-control" value="www.pulsecarwash.com">
                            </div>
                            <div class="col-md-12">
                                <label class="form-label">Address</label>
                                <input type="text" class="form-control" value="123 Main St, Manila, Philippines">
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Social Links -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h3 class="section-title">Social Links</h3>
                    <form class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Facebook</label>
                            <input type="text" class="form-control" value="https://facebook.com/pulsecarwash">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Instagram</label>
                            <input type="text" class="form-control" value="https://instagram.com/pulsecarwash">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Twitter</label>
                            <input type="text" class="form-control" value="https://twitter.com/pulsecarwash">
                        </div>
                        <div class="col-12 mt-3">
                            <button type="submit" class="btn btn-gradient">Save Social Links</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Preview Card -->
            <div class="card shadow-sm mb-4">
                <div class="card-body text-center">
                    <h3 class="section-title">Dashboard Preview</h3>
                    <p>Get a quick overview of your business stats, social reach, and customer engagement in real time.</p>
                    <div class="social-links">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                    </div>
                    <button class="btn btn-gradient mt-3">Open Dashboard</button>
                </div>
            </div>

        </main>
    </div>
</div>