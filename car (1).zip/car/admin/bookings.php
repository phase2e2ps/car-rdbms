<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

<!-- Custom CSS -->
<style>
    /* ---------- GLOBAL ---------- */
    body {
        font-family: 'Segoe UI', sans-serif;
        line-height: 1.6;
        scroll-behavior: smooth;
    }

    a {
        text-decoration: none;
    }

    /* ---------- NAVBAR ---------- */
    .navbar-dark .navbar-nav .nav-link {
        color: #fff;
        transition: color 0.3s;
    }

    .navbar-dark .navbar-nav .nav-link:hover {
        color: #ffc107;
    }

    .navbar-brand svg {
        fill: #fff;
    }

    /* ---------- HERO ---------- */
    .hero {
        background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://framerusercontent.com/assets/jPGmgjk0UnrlNS7OFk2YvyM4c.mp4') center/cover no-repeat;
        color: #fff;
        text-align: center;
        padding: 120px 15px;
    }

    .hero h1 {
        font-size: 3rem;
        font-weight: 700;
    }

    .hero p {
        font-size: 1.2rem;
    }

    .btn-warning {
        font-weight: 600;
        border-radius: 50px;
        padding: 0.7rem 1.5rem;
    }

    /* ---------- WHY CHOOSE US ---------- */
    .features i {
        font-size: 2.5rem;
        margin-bottom: 15px;
    }

    /* ---------- SERVICES ---------- */
    .services .card {
        border: none;
        border-radius: 16px;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .services .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    }

    /* ---------- STATS ---------- */
    .stats {
        color: #fff;
        text-align: center;
    }

    .stats h2 {
        font-size: 2rem;
        font-weight: 700;
    }

    .stats p {
        font-size: 1rem;
    }

    /* ---------- PRICING ---------- */
    .price {
        background: #f9f9f9;
        padding: 60px 0;
    }

    .price-item {
        border-radius: 16px;
        background: #fff;
        transition: all 0.3s;
        padding: 30px 20px;
    }

    .price-item:hover {
        transform: translateY(-8px);
        box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
    }

    .featured-item {
        border: 2px solid #6C63FF;
    }

    .featured-item h2 {
        color: #6C63FF;
    }

    .price-item ul li {
        padding: 0.6rem 0;
        border-bottom: 1px solid #f0f0f0;
    }

    .btn-gradient {
        background: linear-gradient(135deg, #4e54c8, #8f94fb);
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-gradient:hover {
        background: linear-gradient(135deg, #3b3f99, #6c70d8);
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    /* ---------- TESTIMONIALS ---------- */
    blockquote {
        font-size: 1.1rem;
        font-style: italic;
    }

    /* ---------- CONTACT ---------- */
    iframe {
        border: none;
        border-radius: 16px;
    }

    /* ---------- FOOTER ---------- */
    .footer {
        background: #212529;
        color: #fff;
        padding: 30px 0;
    }

    .footer p {
        margin: 0;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php include "./sidebar.php"; ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Bookings</h1>
                <div>
                    <input type="text" class="form-control" placeholder="🔍 Search booking...">
                </div>
            </div>

            <!-- Bookings Table -->
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">All Bookings</h5>
                </div>
                <div class="card-body p-0">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Client</th>
                                <th>Service</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Example Rows -->
                            <tr>
                                <td>1</td>
                                <td>Juan Dela Cruz</td>
                                <td>Premium Wash</td>
                                <td>2025-09-26</td>
                                <td>10:00 AM</td>
                                <td><span class="badge bg-warning text-dark">Pending</span></td>
                                <td>
                                    <button class="btn btn-sm btn-success"><i class="bi bi-check-circle"></i> Approve</button>
                                    <button class="btn btn-sm btn-info"><i class="bi bi-pencil-square"></i> Reschedule</button>
                                    <button class="btn btn-sm btn-danger"><i class="bi bi-x-circle"></i> Cancel</button>
                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Maria Santos</td>
                                <td>Basic Wash</td>
                                <td>2025-09-27</td>
                                <td>2:00 PM</td>
                                <td><span class="badge bg-success">Approved</span></td>
                                <td>
                                    <button class="btn btn-sm btn-info"><i class="bi bi-pencil-square"></i> Reschedule</button>
                                    <button class="btn btn-sm btn-danger"><i class="bi bi-x-circle"></i> Cancel</button>
                                </td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Jose Rizal</td>
                                <td>Complex Wash</td>
                                <td>2025-09-28</td>
                                <td>4:00 PM</td>
                                <td><span class="badge bg-danger">Cancelled</span></td>
                                <td>
                                    <button class="btn btn-sm btn-success"><i class="bi bi-check-circle"></i> Approve</button>
                                    <button class="btn btn-sm btn-info"><i class="bi bi-pencil-square"></i> Reschedule</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Custom CSS -->
<style>
    .sidebar {
        height: 100vh;
    }

    .sidebar .nav-link.active {
        background: rgba(255, 255, 255, 0.1);
        font-weight: bold;
    }

    .table td,
    .table th {
        vertical-align: middle;
    }
</style>