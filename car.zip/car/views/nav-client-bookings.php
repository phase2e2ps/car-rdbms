    <!--Navigation Bar-->
    <?php
    include "../nav/header.php";
    ?>
    <!--Navigation Bar-->

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!--Bootstrap CDN-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>

        <title>Client Bookings Dashboard</title>
    </head>

    <body>
        <h1 style="text-align: center;">Bookings</h1>
        <br><br>
        <section>
            <div class="row">
                <div class="col-md-6">
                    <h1>div1</h1>
                </div>
                <div class="col-md-6">
                    <h1>div2</h1>
                </div>
            </div>
        </section>
        <section>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Address</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Gers</td>
                        <td>gers@gmail.com</td>
                        <td>Pawing Palo Tacloban City</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Jovanna</td>
                        <td>jovanna@gmail.com</td>
                        <td>Pawing Palo Tacloban City</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Mikay</td>
                        <td>mikay@gmail.com</td>
                        <td>Pawing Palo Tacloban City</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>Jermaine</td>
                        <td>jermaine@gmail.com</td>
                        <td>Pawing Palo Tacloban City</td>
                    </tr>
                </tbody>
            </table>
        </section>

        <!--Footer-->
        <?php
        include "../nav/footer.php";
        ?>
        <!--End Footer-->
    </body>

    </html>