    <!--Navigation Bar-->
    <?php
    include "../nav/header.php";
    ?>
    <!--Navigation Bar-->

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

    <!-- Custom CSS -->
    <style>
        /* ---------- GLOBAL ---------- */
        body {
            font-family: 'Segoe UI', sans-serif;
            line-height: 1.6;
            scroll-behavior: smooth;
        }

        a {
            text-decoration: none;
        }

        /* ---------- NAVBAR ---------- */
        .navbar-dark .navbar-nav .nav-link {
            color: #fff;
            transition: color 0.3s;
        }

        .navbar-dark .navbar-nav .nav-link:hover {
            color: #ffc107;
        }

        .navbar-brand svg {
            fill: #fff;
        }

        /* ---------- HERO ---------- */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://framerusercontent.com/assets/jPGmgjk0UnrlNS7OFk2YvyM4c.mp4') center/cover no-repeat;
            color: #fff;
            text-align: center;
            padding: 120px 15px;
        }

        .hero h1 {
            font-size: 3rem;
            font-weight: 700;
        }

        .hero p {
            font-size: 1.2rem;
        }

        .btn-warning {
            font-weight: 600;
            border-radius: 50px;
            padding: 0.7rem 1.5rem;
        }

        /* ---------- WHY CHOOSE US ---------- */
        .features i {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }

        /* ---------- SERVICES ---------- */
        .services .card {
            border: none;
            border-radius: 16px;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .services .card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }

        /* ---------- STATS ---------- */
        .stats {
            color: #fff;
            text-align: center;
        }

        .stats h2 {
            font-size: 2rem;
            font-weight: 700;
        }

        .stats p {
            font-size: 1rem;
        }

        /* ---------- PRICING ---------- */
        .price {
            background: #f9f9f9;
            padding: 60px 0;
        }

        .price-item {
            border-radius: 16px;
            background: #fff;
            transition: all 0.3s;
            padding: 30px 20px;
        }

        .price-item:hover {
            transform: translateY(-8px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
        }

        .featured-item {
            border: 2px solid #6C63FF;
        }

        .featured-item h2 {
            color: #6C63FF;
        }

        .price-item ul li {
            padding: 0.6rem 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .btn-gradient {
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-gradient:hover {
            background: linear-gradient(135deg, #3b3f99, #6c70d8);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
        }

        /* ---------- TESTIMONIALS ---------- */
        blockquote {
            font-size: 1.1rem;
            font-style: italic;
        }

        /* ---------- CONTACT ---------- */
        iframe {
            border: none;
            border-radius: 16px;
        }

        /* ---------- FOOTER ---------- */
        .footer {
            background: #212529;
            color: #fff;
            padding: 30px 0;
        }

        .footer p {
            margin: 0;
        }
    </style>

    <!-- Stats -->
    <section class="stats py-5" style="background: linear-gradient(135deg, #4e54c8, #8f94fb);">
        <div class="container">
            <div class="row g-4 text-center text-white">
                <div class="col-md-3">
                    <h2 class="fw-bold">5000+</h2>
                    <p>Cars Washed</p>
                </div>
                <div class="col-md-3">
                    <h2 class="fw-bold">3000+</h2>
                    <p>Happy Clients</p>
                </div>
                <div class="col-md-3">
                    <h2 class="fw-bold">50+</h2>
                    <p>Staff Members</p>
                </div>
                <div class="col-md-3">
                    <h2 class="fw-bold">10+</h2>
                    <p>Branches</p>
                </div>
            </div>
        </div>
    </section>



    <!-- Services Section -->
    <section id="services" class="py-5">
        <div class="container">
            <h2 class="text-center mb-4">Our Services</h2>
            <div class="row g-4">
                <div class="col-md-4 text-center">
                    <i class="bi bi-droplet-fill fs-1 text-primary"></i>
                    <h4 class="mt-2">Exterior Wash</h4>
                    <p>Complete exterior cleaning, waxing, and polishing for a sparkling look.</p>
                </div>
                <div class="col-md-4 text-center">
                    <i class="bi bi-car-front-fill fs-1 text-primary"></i>
                    <h4 class="mt-2">Interior Cleaning</h4>
                    <p>Vacuuming, seat washing, and full interior sanitation for comfort.</p>
                </div>
                <div class="col-md-4 text-center">
                    <i class="bi bi-bucket-fill fs-1 text-primary"></i>
                    <h4 class="mt-2">Special Services</h4>
                    <p>Engine wash, tire polish, wax coating, and additional premium services.</p>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <!--Booking Modal-->
    <?php
    include "./booking-modal.php";
    ?>
    <!--End Booking Modal-->

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-3">
        &copy; 2025 Carwash Management System
    </footer>