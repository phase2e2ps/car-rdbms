    <!--Navigation Bar-->
    <?php
    include "../nav/header.php";
    ?>
    <!--Navigation Bar-->






    <!--Footer-->
    <?php
    include "../nav/footer.php";
    ?>
    <!--End Footer-->