<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carwash Admin Panel</title>

    <!-- Bootstrap 4 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">

    <!-- DataTables (Bootstrap 4 integration) -->
    <link href="https://cdn.datatables.net/v/bs4/dt-2.3.4/datatables.min.css" rel="stylesheet">

    <style>
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            min-height: 100vh;
        }

        .nav-link.active {
            background-color: #0d6efd !important;
            color: #fff !important;
            font-weight: 600;
        }

        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.15);
            transition: 0.3s ease;
        }

        main {
            min-height: 100vh;
            background: #f8f9fa;
            padding: 20px;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
                <div class="position-sticky pt-3 text-white">
                    <h5 class="px-3 mb-3">Carwash Admin Panel</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link text-white active" href="./index.php">
                                <i class="fas fa-tachometer-alt mr-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="./bookings.php">
                                <i class="fas fa-calendar-check mr-2"></i> Manage Bookings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="./clients.php">
                                <i class="fas fa-users mr-2"></i> Clients
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="./services.php">
                                <i class="fas fa-list mr-2"></i> Services & Plans
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="./reports.php">
                                <i class="fas fa-chart-line mr-2"></i> Reports
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="./settings.php">
                                <i class="fas fa-cog mr-2"></i> Settings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="../views/index.php">
                                <i class="fas fa-sign-out-alt mr-2"></i> Log Out
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h4 class="text-primary">User Management</h4>
                    <div>
                        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addModal">
                            <i class="fas fa-user-plus"></i> Add User
                        </button>
                        <button class="btn btn-success btn-sm">
                            <i class="fas fa-file-excel"></i> Export
                        </button>
                    </div>
                </div>

                <!-- DataTable -->
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="userTable" class="table table-striped table-bordered table-hover text-center">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Id</th>
                                        <th>First Name </th>
                                        <th>Last Name</th>
                                        <th>E-mail</th>
                                        <th>Phone</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    require_once "../db/booking-modal.php";
                                    
                                    // ================= Fetch Bookings ================= //
                                    $bookingsobj = new booking();
                                    $bookings = $bookingsobj->getAllBookings();
                                    ?>

                                    <?php //for ($i = 1; $i <= 100; $i++): ?>
                                        <?php foreach($bookings as $b):?>
                                        <tr>
                                            <td><?= $b['id']; ?></td>
                                            <td> <?= $b['booking_type']; ?></td>
                                            <td> <?= $b['washing_point']; ?></td>
                                            <td> <?= $b['name_tb']; ?></td>
                                            <td> <?= $b['sched_tb']?></td>
                                            <td>
                                                <a href="#" class="text-success mx-1"><i class="fas fa-info-circle"></i></a>
                                                <a href="#" class="text-primary mx-1"><i class="fas fa-edit"></i></a>
                                                <a href="#" class="text-danger mx-1"><i class="fas fa-trash-alt"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach;?>
                                    <?php //endfor; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal fade" id="addModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add User</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body px-4">
                    <form>
                        <div class="form-group">
                            <input type="text" name="fname" class="form-control" placeholder="First Name" required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="lname" class="form-control" placeholder="Last Name" required>
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" class="form-control" placeholder="E-mail" required>
                        </div>
                        <div class="form-group">
                            <input type="tel" name="phone" class="form-control" placeholder="Phone No." required>
                        </div>
                        <button type="submit" class="btn btn-success btn-block">Add User</button>
                    </form>
                </div>
                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/v/bs4/dt-2.3.4/datatables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- DataTables Init -->
    <script>
        $(document).ready(function() {
            var table = $("#userTable").DataTable({
                dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                    '<"row"<"col-sm-12"tr>>' +
                    '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7 d-flex justify-content-end"p>>'
            });

            // Style pagination buttons with Bootstrap
            table.on('draw', function() {
                $('.dataTables_paginate .paginate_button').addClass('btn btn-primary btn-sm mx-1');
                $('.dataTables_paginate .paginate_button.current')
                    .removeClass('btn-primary')
                    .addClass('btn-dark');
            });
        });
    </script>
</body>

</html>