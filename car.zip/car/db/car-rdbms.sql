-- phpMyAdmin SQL Dump
-- version 5.2.1deb1+deb12u1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 25, 2025 at 04:00 PM
-- Server version: 10.11.11-MariaDB-0+deb12u1
-- PHP Version: 8.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car`
--
CREATE DATABASE IF NOT EXISTS `car` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `car`;

-- --------------------------------------------------------

--
-- Table structure for table `contact_tb`
--

CREATE TABLE `contact_tb` (
  `id` int(11) NOT NULL,
  `name_tb` varchar(100) NOT NULL,
  `email_tb` varchar(100) NOT NULL,
  `address_tb` varchar(100) NOT NULL,
  `contact_no` bigint(100) NOT NULL,
  `message_tb` varchar(1000) NOT NULL,
  `date_tb` date DEFAULT current_timestamp(),
  `status_tb` enum('Read','Unread') NOT NULL DEFAULT 'Unread'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_tb`
--

INSERT INTO `contact_tb` (`id`, `name_tb`, `email_tb`, `address_tb`, `contact_no`, `message_tb`, `date_tb`, `status_tb`) VALUES
(1, 'Gers', 'gers@gmail.com', 'brgy dita julita leyte', 9887440217, 'Can you pleas set an schedule for me at Sep 30 2025 for a Carwash Interior Washing. I\'ll be there soon.', NULL, 'Unread'),
(2, 'Gers', 'gers@gmail.com', 'brgy dita julita leyte', 9887440217, 'Can you pleas set an schedule for me at Sep 30 2025 for a Carwash Interior Washing. I\'ll be there soon.', NULL, 'Unread'),
(3, 'Gers', 'okayfine@gmail.com', 'brgy dita julita leyte', 9887440217, 'Can you pleas set an schedule for me at Sep 30 2025 for a Carwash Interior Washing. I\'ll be there soon.', NULL, 'Unread'),
(4, 'Gers', 'okayfine@gmail.com', 'brgy dita julita leyte', 9887440217, 'Can you pleas set an schedule for me at Sep 30 2025 for a Carwash Interior Washing. I\'ll be there soon.', '2025-09-25', 'Unread'),
(5, 'Jovanna', 'jovanna@gmail.com', 'Palo Tacloban City', 9887440217, 'Can you pleas set an schedule for me at Sep 30 2025 for a Carwash Interior Washing. I\'ll be there soon.', '2025-09-25', 'Unread'),
(6, 'Gers', 'Anonymous@gmail.com', 'Palo Tacloban City', 9887440217, 'Carwash Interior Washing', '2025-09-25', 'Unread'),
(7, 'Jovanna', 'jovanna@gmail.com', 'Palo Tacloban City', 9887440217, 'Carwash Interior Washing', '2025-09-25', 'Unread'),
(8, 'Gers', 'gers@gmail.com', 'Palo Tacloban City', 9887440217, 'Car wash Full Detailing', '2025-09-25', 'Unread');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_tb`
--
ALTER TABLE `contact_tb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_tb`
--
ALTER TABLE `contact_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
