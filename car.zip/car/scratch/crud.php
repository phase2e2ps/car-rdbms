<?php
include "db_connection.php";

class Booking extends Database
{
    private $conn;

    public function __construct()
    {
        $this->conn = $this->connect();
    }

    /** ---------------- CREATE ---------------- */
    public function addBooking($data)
    {
        // Make sure extra_services is a string
        if (isset($data['extra_services']) && is_array($data['extra_services'])) {
            $data['extra_services'] = implode(',', $data['extra_services']);
        }

        $insert = 
        "INSERT INTO booking_tb 
                (booking_type, washing_point, name_tb, email_tb, phone_no, car_model, message_tb, extra_services, sched_tb, wash_time)
         VALUES            
                (:package_type, :washing_point, :full_name, :email, :mobile_no, :car_model, :message, :extra, :wash_date, :wash_time)
        ";
        $stmt = $this->conn->prepare($insert);
        $stmt->bindParam(":package_type",   $data['booking_type']);
        $stmt->bindParam(":washing_point",  $data['washing_point']);
        $stmt->bindParam(":full_name",      $data['name_tb']);
        $stmt->bindParam(":email",          $data['email_tb']);
        $stmt->bindParam(":mobile_no",      $data['phone_no']);
        $stmt->bindParam(":car_model",      $data['car_model']);
        $stmt->bindParam(":message",        $data['message_tb']);
        $stmt->bindParam(":extra",          $data['extra_services']);
        $stmt->bindParam(":wash_date",      $data['sched_tb']);
        $stmt->bindParam(":wash_time",      $data['wash_time']);
        return $stmt->execute();
    }

    /** ---------------- READ ---------------- */
    public function getAllBookings()
    {
        $sql = "SELECT * FROM booking_tb ORDER BY sched_tb DESC, wash_time ASC";
        $stmt = $this->conn->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getBookingById($id)
    {
        $sql = "SELECT * FROM booking_tb WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /** ---------------- UPDATE ---------------- */
    public function updateBooking($id, $data)
    {
        if (isset($data['extra_services']) && is_array($data['extra_services'])) {
            $data['extra_services'] = implode(',', $data['extra_services']);
        }

        $update = 
        "  UPDATE booking_tb SET
                booking_type = :package_type,
                washing_point = :washing_point,
                name_tb = :full_name,
                email_tb = :email,
                phone_no = :mobile_no,
                car_model = :car_model,
                message_tb = :message,
                extra_services = :extra,
                sched_tb = :wash_date,
                wash_time = :wash_time
            WHERE id = :id
        ";
        $stmt = $this->conn->prepare($update);
        $stmt->bindParam(":package_type",   $data['booking_type']);
        $stmt->bindParam(":washing_point",  $data['washing_point']);
        $stmt->bindParam(":full_name",      $data['name_tb']);
        $stmt->bindParam(":email",          $data['email_tb']);
        $stmt->bindParam(":mobile_no",      $data['phone_no']);
        $stmt->bindParam(":car_model",      $data['car_model']);
        $stmt->bindParam(":message",        $data['message_tb']);
        $stmt->bindParam(":extra",          $data['extra_services']);
        $stmt->bindParam(":wash_date",      $data['sched_tb']);
        $stmt->bindParam(":wash_time",      $data['wash_time']);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    /** ---------------- DELETE ---------------- */
    public function deleteBooking($id)
    {
        $delete = "DELETE FROM booking_tb WHERE id = :id";
        $stmt = $this->conn->prepare($delete);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}
