<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
</head>

<body>
    <!-- Footer Start -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                </div>

            </div>
        </div>
        <div class="container copyright">
            <p style="text-align: center;">&copy; <?php echo date("Y/M/D"); ?> Carwash Management System</p>
        </div>
    </div>
    <!-- Footer End -->
</body>

</html>