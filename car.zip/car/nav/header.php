    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="#">Carwash</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="../views/index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="../views/services.php">Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="../views/plans.php">Plans</a></li>
                    <li class="nav-item"><a class="nav-link" href="../views/contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="../admin/index.php">Admin</a></li>
                </ul>
                <div class="d-flex">
                    <a href="../views/client-log.php" class="btn btn-warning bg-info me-2">Login</a>
                    <a href="../views/client-register.php" class="btn btn-warning">Sign-up</a>
                </div>
            </div>
        </div>
    </nav>