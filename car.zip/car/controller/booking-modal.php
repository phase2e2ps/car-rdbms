<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../db/booking-modal.php";

#------------------------------------------------------------------------#
// global variables
$action['page'] = 'booking-modal';
$action['subpage'] = isset($_GET['subpage']) ? $_GET['subpage'] : 'booking';
#------------------------------------------------------------------------#



#------------------------------------------------------------------------#
//====>preparetion for form submition<====//
if (isset($_GET['function']) && $_GET['function'] === 'addBooking') {
    // if the form submitted successfully the server use this forst line "activeUser"
    $handler = new activeUser($action);
    $handler->bookNow();
} else {
    // else if the form failed to submit the server use this line "defaultUser"
    new defaultUser($action);
}
#------------------------------------------------------------------------#



#------------------------------------------------------------------------#
class defaultUser
{
    private $page    = "";
    private $subpage = "";
    private $user    = "";

    function __construct($page)
    {
        $this->page      = $page['page'];
        $this->subpage   = $page['subpage'];
        $this->user = new Booking();

        include "../views/booking-modal.php";
    }
}
#------------------------------------------------------------------------#



#------------------------------------------------------------------------#
class activeUser
{
    private $page     = "";
    private $subpage  = "";
    private $user     = "";

    function __construct($page)
    {
        $this->page     = $page['page'];
        $this->subpage  = $page['subpage'];
        $this->user     = new Booking();
    }

    // handle booking modal form submition
    function bookNow()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data =
                [
                    'booking_type'      =>  $_POST['package_type'] ?? '',
                    'washing_point'     =>  $_POST['washing_point'] ?? '',
                    'name_tb'           =>  $_POST['full_name'] ?? '',
                    'email_tb'          =>  $_POST['email'] ?? '',
                    'phone_no'          =>  $_POST['mobile_no'] ?? '',
                    'car_model'         =>  $_POST['car_model'] ?? '',
                    'message_tb'        =>  $_POST['message'] ?? '',
                    'extra_services'    =>  $_POST['extra'] ?? '',
                    'sched_tb'          =>  $_POST['wash_date'] ?? '',
                    'wash_time'         =>  $_POST['wash_time'] ?? ''
                ];

            // check if the form was submitted successfully
            if ($this->user->addBooking($data)) {
                $_SESSION['bookNow'] = true;
                echo
                "
                             <script>
                                  alert('Message sent successfully!'); 
                                  window.location.href='../views/index.php'
                             </script>
                        ";
            } else {
                // else if failed to submit the form this errors line will popup
                echo  "<script>alert('Failed to save contact message.');</script>";
            }
        }
    }
}
#------------------------------------------------------------------------#
